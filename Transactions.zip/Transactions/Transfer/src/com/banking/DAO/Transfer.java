
package com.banking.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.banking.userBean.Simple;
import com.banking.userBean.User;
import com.banking.utils.ConnectionJDBC;

public class Transfer {
	private static String getTransactions="Select * from transactions where acc_no=?";
	private static String newTransaction1="insert into transactions(acc_no,instance,amount,to_account,debit) values(?,?,?,?,?)";
	//private static String newTransaction2="update transactions set amount=amount-? where acc_no=?";
	private static String newTransaction3="select amount from transactions where sl_no in(select max(sl_no) from transactions where acc_no=?)";

	ConnectionJDBC con=new ConnectionJDBC();
	Connection getCon=con.getConnection();
	public ArrayList<Simple> getTransactionDetails(Simple td) throws SQLException
	{
		
		ArrayList<Simple> transactions=new ArrayList<Simple>();
		PreparedStatement stmt=getCon.prepareStatement(getTransactions);
		stmt.setString(1, td.getUser().getAccNumber());
		ResultSet rs=stmt.executeQuery();
		while(rs.next())
		{
			String date=rs.getString(3);
			Double amount=rs.getDouble(4);
			String toAccount=rs.getString(5);
			double debit=rs.getDouble(6);
			Simple td2=new Simple(date, amount,td.getUser(),toAccount,debit);
			transactions.add(td2);
		}
		
		return transactions;
		
		
	}
	
	public ArrayList<Simple> newTransaction(Simple td) throws SQLException
	{
			PreparedStatement stmt3=getCon.prepareStatement(newTransaction3);
			stmt3.setString(1,td.getUser().getAccNumber());
			ResultSet rs=stmt3.executeQuery();
			Double temp = 0.00;
			while(rs.next())
			{
				temp=rs.getDouble(1);
			}
			
			PreparedStatement stmt1=getCon.prepareStatement(newTransaction1);
			stmt1.setString(1,td.getUser().getAccNumber());
			stmt1.setString(2,td.getDate());
			stmt1.setDouble(3,temp-td.getDebit());
			//stmt1.setDouble(4,td.getDebit());
			stmt1.setString(4,td.getToAccount());
			stmt1.setDouble(5,td.getDebit());
			
			stmt1.executeUpdate();
			return getTransactionDetails(td);
		
	}
}
