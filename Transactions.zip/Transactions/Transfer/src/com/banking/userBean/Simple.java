package com.banking.userBean;

public class Simple {
private String date;
private double amount;
private User user;
private String toAccount;
private double debit;
public Simple(String date, double amount, User user,String toAccount,double debit) {
	super();
	this.date = date;
	this.amount = amount;
	this.user = user;
	this.toAccount=toAccount;
	this.debit=debit;
}

public Simple(String date,User user,String toAccount,double debit) {
	this.date = date;
	this.user = user;
	this.toAccount=toAccount;
	this.debit=debit;
}

public double getDebit() {
	return debit;
}

public void setDebit(double debit) {
	this.debit = debit;
}

public String getToAccount() {
	return toAccount;
}

public void setToAccount(String toAccount) {
	this.toAccount = toAccount;
}

public Simple(){}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

public User getUser() {
	return user;
}

public void setUser(User user) {
	this.user = user;
};


}
