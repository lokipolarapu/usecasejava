package com.banking.userBean;

public class User {

	private String accNumber;

	public User(String accNumber) {
		super();
		this.accNumber = accNumber;
	}
	
	public User()
	{
		
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	
	
	
}
