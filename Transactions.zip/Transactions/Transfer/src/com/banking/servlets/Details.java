package com.banking.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.banking.DAO.Transfer;
import com.banking.userBean.Simple;
import com.banking.userBean.User;

/**
 * Servlet implementation class AccountInfo
 */
@WebServlet("/AccountInfo")
public class Details extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String myAccount;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Details() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		DateTimeFormatter dt=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		LocalDateTime date=LocalDateTime.now();

		String toAccount=request.getParameter("acc_number");
		double debit=Double.parseDouble(request.getParameter("debit"));
		String instance=dt.format(date).toString();
		
		User user=new User();
		user.setAccNumber(myAccount);
		ArrayList<Simple> listTrans=new ArrayList<Simple>();
		try {
		 listTrans=new Transfer().newTransaction(new Simple(instance,user,toAccount,debit)); 
		 }
		catch (SQLException e) { // TODO
	   e.printStackTrace();
	  }
		
		
		request.setAttribute("return",listTrans);
		getServletConfig().getServletContext().getRequestDispatcher("/trans.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 		myAccount=request.getParameter("acc_Number");
				User user=new User();
				user.setAccNumber(myAccount);
				Simple td=new Simple();
				td.setUser(user);
				ArrayList<Simple>
				 listTrans=new ArrayList<Simple>();
				try {
				 listTrans=new Transfer().newTransaction(td); 
				 }
				catch (SQLException e) { // TODO
			   e.printStackTrace();
			  }
				
				if(listTrans.size()==0)
				{
					request.setAttribute("auth", true);
				}
				else
				{
					request.setAttribute("auth", false);
				}
			request.setAttribute("welcome",listTrans);
			getServletConfig().getServletContext().getRequestDispatcher("/Refer.jsp").forward(request, response);
	}

}
